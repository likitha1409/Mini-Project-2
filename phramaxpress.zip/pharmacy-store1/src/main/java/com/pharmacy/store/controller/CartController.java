package com.pharmacy.store.controller;

import com.pharmacy.store.entity.Cart;
import com.pharmacy.store.service.CartService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @PostMapping("/add")
    public ResponseEntity<?> addToCart(@RequestBody Map<String, Object> data) {
        try {
            String email = data.get("email").toString();
            Long productId = Long.parseLong(data.get("productId").toString());
            int quantity = Integer.parseInt(data.get("quantity").toString());

            Cart cart = cartService.addToCart(email, productId, quantity);
            return ResponseEntity.ok(cart);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("❌ Error: " + e.getMessage());
        }
    }

    @GetMapping("/{email}")
    public ResponseEntity<Cart> getCartByEmail(@PathVariable String email) {
        return ResponseEntity.ok(cartService.getCartByEmail(email));
    }
}
