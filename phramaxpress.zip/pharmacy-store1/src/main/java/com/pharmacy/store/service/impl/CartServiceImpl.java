package com.pharmacy.store.service.impl;

import com.pharmacy.store.entity.*;
import com.pharmacy.store.repository.*;
import com.pharmacy.store.service.CartService;
import com.pharmacy.store.service.ProductService;
import com.pharmacy.store.service.UserService;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class CartServiceImpl implements CartService {

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final ProductService productService;
    private final UserService userService;

    public CartServiceImpl(CartRepository cartRepository,
                           CartItemRepository cartItemRepository,
                           ProductService productService,
                           UserService userService) {
        this.cartRepository = cartRepository;
        this.cartItemRepository = cartItemRepository;
        this.productService = productService;
        this.userService = userService;
    }

    @Override
    @Transactional
    public Cart addToCart(String email, Long productId, int quantity) {
        User user = userService.getUserByEmail(email);
        Product product = productService.getProductById(productId);

        Cart cart = cartRepository.findByUser(user).orElse(null);

        if (cart == null) {
            cart = new Cart();
            cart.setUser(user);
            cart.setItems(new ArrayList<>());
        }

        CartItem item = new CartItem();
        item.setCart(cart);
        item.setProduct(product);
        item.setQuantity(quantity);

        cart.getItems().add(item);

        cartRepository.save(cart);
        return cart;
    }

    @Override
    public Cart getCartByEmail(String email) {
        User user = userService.getUserByEmail(email);
        return cartRepository.findByUser(user)
                .orElseThrow(() -> new RuntimeException("Cart not found for user: " + email));
    }
}
