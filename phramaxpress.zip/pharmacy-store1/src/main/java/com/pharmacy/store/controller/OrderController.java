package com.pharmacy.store.controller;

import com.pharmacy.store.entity.Order;
import com.pharmacy.store.service.OrderService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    // ✅ Place order using email from JSON body
    @PostMapping("/place")
    public ResponseEntity<?> placeOrder(@RequestBody Map<String, String> request) {
        try {
            String email = request.get("email");

            if (email == null || email.isEmpty()) {
                return ResponseEntity.badRequest().body("❌ Email is required.");
            }

            System.out.println("📦 Placing order for email: " + email);

            Order order = orderService.placeOrder(email);
            return ResponseEntity.ok(order);

        } catch (Exception e) {
            e.printStackTrace(); // log to console
            return ResponseEntity.badRequest().body("❌ " + e.getMessage());
        }
    }



    // ✅ Get all orders by user email
    @GetMapping("/{email}")
    public ResponseEntity<?> getOrdersByEmail(@PathVariable String email) {
        try {
            List<Order> orders = orderService.getOrdersByEmail(email);
            return ResponseEntity.ok(orders);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("❌ " + e.getMessage());
        }
    }

    // ✅ Get single order by ID
    @GetMapping("/id/{orderId}")
    public ResponseEntity<?> getOrderById(@PathVariable Long orderId) {
        try {
            Order order = orderService.getOrderById(orderId);
            return ResponseEntity.ok(order);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("❌ " + e.getMessage());
        }
    }
}
