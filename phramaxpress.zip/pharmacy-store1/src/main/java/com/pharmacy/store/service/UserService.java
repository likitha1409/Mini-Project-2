// File: UserService.java
package com.pharmacy.store.service;

import com.pharmacy.store.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserService {
    String register(User user);
    Optional<User> login(String email, String password);
    List<User> getAllUsers();
    Optional<User> getUserById(Long id);
    User updateUser(Long id, User user);
    void deleteUser(Long id);

    // ✅ ADD THIS
    User getUserByEmail(String email);
}
