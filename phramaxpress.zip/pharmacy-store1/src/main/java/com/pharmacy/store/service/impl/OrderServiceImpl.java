package com.pharmacy.store.service.impl;

import com.pharmacy.store.entity.*;
import com.pharmacy.store.repository.*;
import com.pharmacy.store.service.OrderService;
import com.pharmacy.store.service.UserService;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    private final UserService userService;
    private final CartRepository cartRepository;
    private final OrderRepository orderRepository;
    private final OrderProductRepository orderProductRepository;
    private final CartItemRepository cartItemRepository;

    public OrderServiceImpl(UserService userService,
                            CartRepository cartRepository,
                            OrderRepository orderRepository,
                            OrderProductRepository orderProductRepository,
                            CartItemRepository cartItemRepository) {
        this.userService = userService;
        this.cartRepository = cartRepository;
        this.orderRepository = orderRepository;
        this.orderProductRepository = orderProductRepository;
        this.cartItemRepository = cartItemRepository;
    }

    @Override
    @Transactional
    public Order placeOrder(String email) {
        // ✅ Get the user once
        User user = userService.getUserByEmail(email);
        System.out.println("🧑 User retrieved: " + user.getEmail());

        // ✅ Retrieve cart using the user
        Cart cart = cartRepository.findByUser(user)
                .orElseThrow(() -> new RuntimeException("Cart not found for user: " + email));
        System.out.println("🛒 Cart retrieved for user: " + cart.getId());

        // ✅ Check if cart has items
        if (cart.getItems().isEmpty()) {
            throw new RuntimeException("Cart is empty.");
        }

        // ✅ Create new order
        Order order = new Order();
        order.setUser(user);
        order.setOrderDate(LocalDateTime.now());

        // ✅ Convert CartItems to OrderProducts
        List<OrderProduct> orderProducts = new ArrayList<>();
        for (CartItem cartItem : cart.getItems()) {
            OrderProduct op = new OrderProduct();
            op.setOrder(order);
            op.setProduct(cartItem.getProduct());
            op.setQuantity(cartItem.getQuantity());
            orderProducts.add(op);
        }

        order.setOrderProducts(orderProducts);

        // ✅ Save Order and its products
        orderRepository.save(order);
        orderProductRepository.saveAll(orderProducts);

        // ✅ Clear cart after order
        cartItemRepository.deleteAll(cart.getItems());
        cart.getItems().clear();
        cartRepository.save(cart);

        return order;
    }

    @Override
    public List<Order> getOrdersByEmail(String email) {
        return orderRepository.findByUserEmail(email);
    }

    @Override
    public Order getOrderById(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
    }
}
