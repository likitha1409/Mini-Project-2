package com.pharmacy.store.service;

import com.pharmacy.store.entity.Cart;

public interface CartService {
    Cart addToCart(String email, Long productId, int quantity);
    Cart getCartByEmail(String email); // ✅ Add this line
}
