package com.pharmacy.store.service;

import com.pharmacy.store.entity.Order;

import java.util.List;

public interface OrderService {
    Order placeOrder(String email);
    List<Order> getOrdersByEmail(String email);
    Order getOrderById(Long orderId);
}
