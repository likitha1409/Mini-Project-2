package com.pharmacy.store.controller;

import com.pharmacy.store.entity.Product;
import com.pharmacy.store.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    // ✅ ADMIN only - Add Product
    @PostMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Map<String, String>> addProduct(@RequestBody Product product) {
        productService.addProduct(product);
        Map<String, String> body = new HashMap<>();
        body.put("message", "✅ Product added successfully");
        return ResponseEntity.ok().body(body);
    }

    // ✅ ADMIN & CUSTOMER - View All
    @GetMapping
    @PreAuthorize("hasAnyAuthority('ADMIN', 'CUSTOMER')")
    public ResponseEntity<List<Product>> getAll() {
        return ResponseEntity.ok(productService.getAllProducts());
    }

    // ✅ ADMIN & CUSTOMER - View by ID
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN', 'CUSTOMER')")
    public ResponseEntity<Product> getById(@PathVariable Long id) {
        return ResponseEntity.ok(productService.getProductById(id));
    }

    // ✅ ADMIN only - Update Product
    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Map<String, String>> update(@PathVariable Long id, @RequestBody Product product) {
        productService.updateProduct(id, product);
        Map<String, String> body = new HashMap<>();
        body.put("message", "✅ Product updated successfully");
        return ResponseEntity.ok().body(body);
    }

    // ✅ ADMIN only - Delete Product
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Map<String, String>> delete(@PathVariable Long id) {
        productService.deleteProduct(id);
        Map<String, String> body = new HashMap<>();
        body.put("message", "✅ Product deleted successfully");
        return ResponseEntity.ok().body(body);
    }
}
